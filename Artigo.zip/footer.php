<center>
<?php
echo "Copyright &copy; 2017-".date("Y").", Todos os direitos reservados.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Versão 1.0.2";
?>
</center>