<table width="760" border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td><div align="center"><img src="imagens/img_topo.gif" width="760" height="120"></div></td>
    </tr>
   </table>

  