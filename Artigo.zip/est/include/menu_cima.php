<table width="760" border="0" cellspacing="0" cellpadding="0">
  <tr> 
    <td width="624"><span class="linkes1"> <a href="<? echo $pontos ?>/intranet.php">Principal</a></span> 
      <font color="#FF0000" size="2" face="Arial, Helvetica, sans-serif">+ </font><font class="font1"><?php echo date("d/m/Y - H:i:s"); ?></font></td>
    <td width="136"></td>
  </tr>
</table>
