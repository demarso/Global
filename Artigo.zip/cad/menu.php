<ul>
	<li onMouseOver="mudaFoto('imagens/home.png')" onMouseOut="mudaFoto('imagens/globo.png')"><a href="../index1.php">Home</a></li>
    <li onMouseOver="mudaFoto('imagens/colaborador.png')" onMouseOut="mudaFoto('imagens/globo.png')"><a href="usuario.php">Usuários</a></li>
<!--<li onMouseOver="mudaFoto('imagens/Workshop.png')" onMouseOut="mudaFoto('imagens/espaco_ico.png')"><a href="#">Festas</a></li>
	<li onMouseOver="mudaFoto('imagens/programa.png')" onMouseOut="mudaFoto('imagens/espaco_ico.png')"><a href="#">Escala</a></li>
	<li onMouseOver="mudaFoto('imagens/inscricao.png')" onMouseOut="mudaFoto('imagens/espaco_ico.png')"><a href="#">Consumo</a></li>
	<li onMouseOver="mudaFoto('imagens/hospedagem.png')" onMouseOut="mudaFoto('imagens/espaco_ico.png')"><a href="#">Receber</a></li>
	<li onMouseOver="mudaFoto('imagens/informa.png')" onMouseOut="mudaFoto('imagens/espaco_ico.png)"><a href="#">Pagar</a></li>
	<li onMouseOver="mudaFoto('imagens/informa.png')" onMouseOut="mudaFoto('imagens/espaco_ico.png)"><a href="#">Caixa</a></li>
	<li onMouseOver="mudaFoto('imagens/informa.png')" onMouseOut="mudaFoto('imagens/espaco_ico.png)"><a href="#">Cadastro</a></li>-->
	<li onMouseOver="mudaFoto('imagens/sair2.png')" onMouseOut="mudaFoto('imagens/globo.png')"><a href="../sair.php">SAIR</a></li>
</ul>