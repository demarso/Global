<div id='cssmenu'>
	<ul>
	<!--	<li onMouseOver="mudaFoto('imagens/home.png')" onMouseOut="mudaFoto('imagens/globo.png')"><a href="index1.php">Home</a></li>
	    <li onMouseOver="mudaFoto('imagens/cadastro.png')" onMouseOut="mudaFoto('imagens/globo.png')"><a href="cadProducao.php">CADASTRO</a></li>
	    <li onMouseOver="mudaFoto('imagens/consulta.png')" onMouseOut="mudaFoto('imagens/globo.png')"><a href="consProducao.php">RASTREADOR</a></li> -->
	    <li><a href="producao.php">Produção</a></li>
	<!--	<li onMouseOver="mudaFoto('imagens/resumo.png')" onMouseOut="mudaFoto('imagens/globo.png')"><a href="quadro.php">Quadro</a></li>-->
		<li><a href="sair.php">SAIR</a></li>
		<li><font size="1">Usu&aacute;rio:&nbsp;<?php echo $_SESSION['nome']; ?></font></li>
		
	</ul>
</div>