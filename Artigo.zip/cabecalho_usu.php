<header id="cabecalho">
     
       <img src="imagens/logo.png" width="200">
       
     <?php	  include "menu_usu.php";   ?>
     
     
 </header>