<?php

require_once("conexao.php");
//echo $_GET[placa];
    $sql = "SELECT placa FROM producao WHERE placa = '$_GET[placa]'";
      $tabela = mysqli_query($conn,$sql) or die(mysql_error());
      $registro = mysqli_num_rows($tabela);
      echo $registro
  /*    if ($registro != 0)
      {
      	 echo "<script>alert(\"Placa já cadastrada!\");location.href='cadProducao.php';</script>";
      }
      else
      	echo "<script>history.go(-1);</script>";
    
    //else
      //echo "<script type = 'text/javascript'> location.href = 'cadProducao.php'</script>"; 
*/
?>