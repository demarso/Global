<header id="cabecalho">
	 <hgroup>
       <img src="imagens/logo.png" width="250">
     </hgroup>
     
</header>
<center><h1>SISTEMAS DE GESTÃO DE PROPOSTAS</h1></center>