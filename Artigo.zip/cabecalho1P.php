<header id="cabecalho">
     
       <img src="imagens/logo.png" width="200">
    
     <?php	 include "menuP.php"; ?>
      
</header>