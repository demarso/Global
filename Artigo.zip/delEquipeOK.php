<?php

require_once("conexao.php");

      $id = $_POST['equipe'];
      

$sql_ini = "DELETE equipe WHERE idEquipe = '$id'";
mysqli_query($conn,$sql_ini) or die (mysql_error());
 
echo "<script type = 'text/javascript'> location.href = 'index1.php'</script>"; 

?>