<div class="navigation">
    <ul class="menu" id="menu">
        <li><span class="#"></span><a href="index1.php" class="first">Home</a></li>
        <li><span class="#"></span><a href="usuario.php">Cadastra</a></li>
        <li><span class="#"></span><a href="usuario_lista.php">Lista</a></li>
        <li><span class="#"></span><a href="usuario_acesso.php">Acessos</a></li>
        <li><span class="#"></span><a href="sair.php" class="last">Sair</a></li>
    </ul>
</div>