 <div id='cssmenu'>
    <ul >
        <li><a href="index1.php" class="first">Home</a></li>
         <li><a href="#">Cadastros</a>
             <ul>
               <li><a href='banco.php'>Bancos</a></li>
             </ul>
        </li>
        <li><a href="entrada.php">Entradas</a></li>
        <li><a href="saida.php">Saídas</a></li>
    <!--    <li><a href="relatorio.php">Relatórios</a></li>
        <li><a href="usuario_lista.php">Usuários</a></li>-->
        <li><a href="sair.php" class="last">Sair</a></li>
        <li>
          <font size="2" color="blue"><b>&nbsp;&nbsp;&nbsp;&nbsp;Usuário:&nbsp;&nbsp;<? echo $_SESSION['nomeF'];  ?></b></font>
</li>
    </ul>
</div>
