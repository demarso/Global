<?php
session_start();
date_default_timezone_set('America/Sao_Paulo');
if (!isset($_SESSION['idF'])){
    header("Location: index.php?erro=1");
    exit;
 }
 if($_SESSION['nivelF'] != 10){
   echo "<script>alert('Você não tem permissão para acessar está página!');history.back(-1);</script>";
   exit;
  }
require_once("conexao.php");

$id = $_GET['id'];

   $sql = "UPDATE sangria SET status=1 where idSangria = '$id'";
    $result = @mysqli_query($conn,$sql);

		//$sql = "DELETE FROM sangria WHERE idSangria = '$id'";
		//mysqli_query($conn,$sql) or die (mysql_error());
 
echo "<script type = 'text/javascript'> location.href = 'saida_caixa_lista.php'</script>"; 

?>