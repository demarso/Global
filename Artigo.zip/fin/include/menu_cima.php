<table width="760" border="0" cellspacing="0" cellpadding="0">
  <tr> 
    <td width="624"><font class="font1"><?php echo date("d/m/Y - H:i:s"); ?></font></td>
    <td width="136"></td>
  </tr>
</table>
