<table width="760" border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td><div align="center"><img src="imagens/Logo.jpg" width="100" height="100"></div></td>
      <td><div align="center"><font size="+2">CONTROLE DE ESTOQUE -</font></div></td>
      <td><div align="center"><font size="+2">MATERIAL DE MANUTEN��O</font></div></td> 
    </tr>
 </table>

  