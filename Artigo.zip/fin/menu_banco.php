<div class="navigation">
    <ul class="menu" id="menu">
        <li><span class="#"></span><a href="index1.php" class="first">Home</a></li>
        <li><span class="#"></span><a href="banco.php">Cadastra</a></li>
        <li><span class="#"></span><a href="banco_lista.php">Lista</a></li>
    </ul>
</div>