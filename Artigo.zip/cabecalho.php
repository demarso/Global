<header id="cabecalho">
	 <hgroup>
       <img src="imagens/logo.png" width="250">
     </hgroup>
     
</header>
<center><h1>SISTEMAS DE GESTÃO GLOBAL</h1></center>