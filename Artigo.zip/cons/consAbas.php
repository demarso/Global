<?php
  session_start();
  date_default_timezone_set('America/Sao_Paulo');
  
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta http-equiv="Content-type" content="text/html; charset=UTF-8"/>
  <link rel="stylesheet" type="text/css" href="estilo.css"/>
  <link rel="stylesheet" href="../css/style_menu.css" type="text/css"/>
        <script type="text/javascript" src="../include/jquery-1.3.2.js"></script>
        <script type="text/javascript" src="../include/script.js"></script>
        <script type="text/javascript" src="../include/jquery-latest.min.js"></script>
        <script type="text/javascript" src="../include/script_menu.js"></script>
  <script type="text/javascript">
        $(document).ready(function(){
        $("#content div:nth-child(1)").show();
        $(".abas li:first div").addClass("selected");   
          $(".aba").click(function(){
            $(".aba").removeClass("selected");
            $(this).addClass("selected");
            var indice = $(this).parent().index();
            indice++;
            $("#content div").hide();
            $("#content div:nth-child("+indice+")").show();
          });
        
          $(".aba").hover(
            function(){$(this).addClass("ativa")},
            function(){$(this).removeClass("ativa")}
          );        
        });

        function carregar(pagina){
        $("#graf").load(pagina);
        }
  </script>
    <style>
      body{font-family:Calibri, Tahoma, Arial}
      .TabControl{ width:100%; overflow:hidden; height:400px}
      .TabControl #header{ width:100%;  overflow:hidden; cursor:hand}
      .TabControl #content{ width:100%; border: solid 2px;overflow:hidden; height:100%; }
      .TabControl .abas{display:inline;}
      .TabControl .abas li{float:left}
      .aba{width:100px; height:30px; border:solid 1px; border-radius:5px 5px 0 0;
        text-align:center; padding-top:5px; background:#3A5FCD}
      .ativa{width:100px; height:30px; border:solid 1 px; border-radius:5px 5px 0 0;
        text-align:center; padding-top:5px; background:#27408B;}
      .ativa span, .selected span{color:#fff}
      .TabControl #content{background:#27408B}
      .TabControl .conteudo{width:100%;  background:#27408B; display:none; height:100%;color:#fff}
      .selected{width:100px; height:30px; border:solid 1 px; border-radius:5px 5px 0 0;
        text-align:center; padding-top:5px; background:#27408B}
    </style>

</head>
<body>
  <?php
   include "cabecalho.php";  
   include 'conexao.php'; 
 ?>
 <form name='form1' action='<? $myself ?>' method='post'>
   <tabel>
    <tr>
       <td><font size="6" color="yellow"><b>   Selecione o Consultor: </b></font></td>
         <td>
          <select name="consultor" id="consultor" onchange="this.form.submit()">
            <option value="">---</option>
              <?php
                
                $sql = "SELECT idConsultor, nome FROM consultor WHERE status='Ativo' ORDER BY nome";
                $results = mysqli_query($conn,$sql);
                while ( $row = mysqli_fetch_array($results) ) {
                  echo "<option value='".$row[0]."'>".$row[1]."</option>";
                }
              ?>
          </select>
         </td>
      </tr>
   </tabel>
  </form>
  <? $consu = $_POST['consultor']; $_SESSION['co'] = $consu;
  $sql1 = "SELECT nome FROM consultor WHERE idConsultor = '$consu'";
   $resultado1 = mysqli_query($conn,$sql1) or die (mysql_error());
   while ($linha1 = mysqli_fetch_array($resultado1)) {
       $consultor1 = $linha1['nome'];
  }
  ?>
<div id="interface">
 <font size="5" color="white">INFORMAÇÕES DO CONSULTOR: </font><font size="5" color="yellow"><? echo $consultor1 ?></font>
  <div class="TabControl">
    <div id="header">
      <ul class="abas">
        <li>
          <div class="aba">
            <span>Dados</span>
          </div>
        </li>
        <li>
          <div class="aba">
            <span>Gráfico</span>
          </div>
        </li>
        <li>
          <div class="aba">
            <span>Produção</span>
          </div>
        </li>
        <li>
          <div class="aba">
            <span>Controle</span>
          </div>
        </li>
      </ul>
    </div>
    <div id="content">
      <div class="conteudo">
        Dados de: <? echo "Cod: ".$consu."  Nome: ".$consultor1; ?>
      </div>
      <div class="conteudo">
        <div id="graf"><? include ('Grafico.php'); ?></script>)</div>
      </div>
      <div class="conteudo">
        <? include 'Producao.php?consultor=".$consu."'; ?>
      </div>
      <div class="conteudo">
       Controles de: <? echo "Cod: ".$consu."  Nome: ".$consultor1; ?>
      </div>
    </div>
  </div>
</div>
 <footer id="footer">   
   <?php include "../footer.php"; ?>
</footer>

</body>
</html>