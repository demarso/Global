<div id='cssmenu'>
    <ul>
    	<li><a href="cons.php">Home</a></li>
    	    <li><a href="#">CONSULTOR</a>
                  <ul>
                    <li><a href="consultor_lista.php">LISTA</a></li>
                    <li><a href="consProducao.php">PRODUÇÃO</a></li>
                    <li><a href="consGrafico.php">GRÁFICO</a></li>
                    <li><a href="consAbas.php">CONTROLE</a></li>
                  </ul>
          </li>
    	
		<li><a href="sair.php">SAIR</a></li>
		<li><font size="1">Usu&aacute;rio:&nbsp;<?php echo $_SESSION['nome']; ?></font></li>
   </ul>
 
</div>