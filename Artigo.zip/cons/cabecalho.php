<header id="cabecalho">
     
       <img src="logo.png" width="200" opacity="50%">
    
     <?php	 include "menu.php"; ?>
      
</header>