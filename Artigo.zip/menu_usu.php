<div id='cssmenu'>
	<ul>
		<li><a href="index1.php">Home</a></li>
		<li><a href="usuario.php">Cadastrar</a></li>
	    <li><a href="usuario_lista.php">Lista</a></li>
	    <li><a href="usuario_acesso.php">Acessos</a></li>
	  	<li><a href="sair.php">SAIR</a></li>
	  	<li><font size="1">Usu&aacute;rio:&nbsp;<?php echo $_SESSION['nome']; ?></font></li>
	</ul>

</div>