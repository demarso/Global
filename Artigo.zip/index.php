<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta http-equiv="Content-type" content="text/html; charset=UTF-8"/>
  <link rel="stylesheet" type="text/css" href="css/estilo.css"/>
  <title>Gestão de Propostas</title> 
</head>
<script type="text/javascript">
	function mudaFoto(foto){
		document.getElementById("icone").src = foto;
	}
</script>
<body>
<?php 
     date_default_timezone_set('America/Sao_Paulo');
     include "cabecalho.php";
    
 ?>
 <div id="interface">
     <br /><br /><br /><br />
	<center>
		<table>
			<tr>
			 <td><a href="indexP.php" target="_blank"><img src="imagens/botaoP.png" width="300px"></a></td><td>&nbsp;&nbsp;&nbsp;&nbsp;</td>
			 <td><a href="fin/index.php" target="_blank"><img src="imagens/botaoF.png" width="300px"></a></td><td>&nbsp;&nbsp;&nbsp;&nbsp;</td>
			 <td><a href="est/index.php" target="_blank"><img src="imagens/botaoE.png" width="300px"></a></td><td>&nbsp;&nbsp;&nbsp;&nbsp;</td>
			</tr>
		<!--	<tr>
			 <td>&nbsp;&nbsp;&nbsp;&nbsp;</td>
			 <td colspan="3" align="center"><a href="#" target="_blank"><img src="imagens/botaoC.png" width="300px"></a></td><td>&nbsp;&nbsp;&nbsp;&nbsp;</td>	
			 <td>&nbsp;&nbsp;&nbsp;&nbsp;</td>
			</tr> -->
		</table>
	</center>	
  </div>
   <footer id="footer">   
   <?php include "footer.php"; ?>
</footer>

</body>
</html>